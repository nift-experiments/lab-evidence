r := cmd("python3", "task_body.py", getenv("NIFT_HOOK_TARGET")).cwd(getenv("NIFT_HOOK_ROOT")).run()
if(!r.launched || r.exit_code != 0) { throw error("Task failed: " + r.stderr, "user.task.failed") }
