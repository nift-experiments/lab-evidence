---
title: "Page 1"
url: "/page-1.html"
---
<h1>Page 1</h1><p>Equivalent benchmark content.</p>
