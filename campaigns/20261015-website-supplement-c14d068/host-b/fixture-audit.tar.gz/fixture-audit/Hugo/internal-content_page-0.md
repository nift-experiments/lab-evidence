---
title: "Page 0"
url: "/"
---
<h1>Page 0</h1><p>Equivalent benchmark content.</p>
