# Equivalent problems, explicit models

Five participants: Nift's native scripting concurrency; ordinary GIL Python with asyncio for waits and process pools for CPU; Node LTS and Bun with promises for waits and worker_threads for CPU; Go compiled goroutines/channels as the concurrency reference. Ruby omitted to keep a compact field rather than add overlapping GIL/thread contrasts.

## Boundaries
Fresh: controller starts clock before launching participant, sends one workload, captures all results and waits for exit. Persistent/booted isolated request: a new participant emits BOOT after loading definitions/imports for each observation; controller excludes that boot, clocks one request dispatch through full response, then tears down outside that boundary. This isolates identical request state for every participant; it does not certify steady-state long-lived repeated-request throughput. Persistent includes IPC, serialization and per-request worker-pool creation/destruction, not a prewarmed permanent CPU pool. Separate repeated-runtime diagnostics retain the Nift completed-future registry growth found in the rejected first cloud cohort. Warmup rounds exercise host/cache state; participant request state is isolated in all rounds. This is request latency, not an isolated engine-internal scheduler clock. Common sampler overhead is included. Nanosecond monotonic clock; smallest requests contain ten tasks, and 50 samples expose distributions. No subtractive startup estimate.

All participants are pinned to the first four permitted CPUs, inherited by threads and child processes. Main official machine has four vCPUs. Explicit CPU/pool workers are exactly 1/2/4; file/process pools use four. Native async scheduler sizing is a runtime policy, not forced to four logical tasks. On a large local host Nift hardware_concurrency can exceed affinity; local times are feasibility only. No official comparisons across hosts.

Common deterministic integer recurrence uses products below 2^53; no hidden library pool. Strong scaling holds 64 jobs and 200000 iterations/job fixed. CPU loops run in-language for every participant. Parent independently recomputes every exact value after timing, sorts by job ID, checks missing/duplicate values, expected child exit codes, recoverable failure codes and counts, then hashes canonical JSON. Warmups retained and marked; no outlier deletion. Held memory uses a common gate: all tasks staged and unfinished while controller measures tree RSS. It does not claim every queued Nift task has begun executing.

## Memory and CPU scope
5ms procfs sampler records summed resident pages over live participant descendants, discovering children across every thread. Shared mappings may be counted more than once; tree RSS is not unique physical memory. Held-tree RSS is a separate checkpoint metric. Fresh wait4 maximum RSS is maximum individual participant/descendant high-water RSS, not tree RSS. Persistent procfs CPU includes reaped descendants; clock ticks limit resolution of short CPU observations. Wall time is the primary metric. Sampler can miss very short-lived children; zero samples are unavailable observations, not proof of zero memory. Held-gate latency includes checkpoint instrumentation and is not an async-wait latency result.

## Model boundaries
Nift sleeps occupy native async workers; Python/JS timers suspend event-loop tasks; Go waits suspend goroutines. These solve the same wait problem with different concurrency costs. Python CPU process-pool startup and JS worker startup are included. Python ordinary GIL threads are not claimed as CPU multicore peers.

Queues capacity 64: Go native channels; Python queue.Queue with native threads; JS bounded cooperative promise queue; Nift explicit mutex-protected ring with 1ms empty/full backoff because no public blocking channel/condition-variable primitive was found. The latter is a documented implementation limitation, not interchangeable channel semantics. All count/IDs/values must match exactly. Nift mutex value get/set copies structured values; no C++ queue shortcut.

Atomics: Nift atomic<int>, Go sync/atomic, JS SharedArrayBuffer/Atomics. Python cell unsupported. Mutex: Nift owner-checked protected-value mutex, Python threading.Lock, Go sync.Mutex; JS unsupported standard native mutex (custom locks intentionally not represented as equivalent). Mutex increments divisible by worker count.

Files: identical pregenerated 10000 × 128-byte corpus, exact byte read/hash; warm Linux cache expected, no cache-dropping claim or disk ranking. Process: identical C helper, argv invocation without shell, deterministic output/exits, same bounded four-job limit. Helper only controls child behavior; it performs none of the in-language computation.

Failure workload collects all outcomes and lets siblings finish. This is all-settled semantics, not fail-fast structured cancellation. Nested futures/promises/goroutines are independently bounded by selected parent/child counts. Cancellation is a separate semantic probe and not pooled into timings.

## Version selection

The field samples five natural models rather than every available runtime. Nift is the exact source snapshot, not the older system executable. Node is the pinned LTS line; Bun supplies a second JS runtime; Go supplies the compiled concurrency reference. Python 3.14.4 was reproducibly available through pinned uv 0.13.0 as an ordinary-GIL portable build. This is not presented as the newest Python patch or a free-threaded comparison. Version/command/binary hashes and installer download identities remain explicit in the environment; no runtime was upgraded during measurement. Ruby was omitted to keep the comparison compact.

For 1000 × 10ms waits, four blocking Nift async workers imply a 2500ms work/worker lower bound; suspended asyncio/JS/Go timers have a 10ms critical-path floor before scheduling/collection overhead. These are waiting semantics, not CPU parallelism.
